<script setup>
// FM2 character: layered cut-outs of the original art.
// Eyes follow the cursor, arm + hand wave. Call wave() via ref, or click the character.
import { ref, onMounted, onBeforeUnmount } from 'vue'
import base from './fm2/base.png'
import armImg from './fm2/arm.png'
import handImg from './fm2/hand.png'
import sleeveImg from './fm2/sleeve.png'
import irisLeftImg from './fm2/iris-left.png'
import irisRightImg from './fm2/iris-right.png'
import lashesImg from './fm2/lashes.png'

const props = defineProps({
  lookRadius: { type: Number, default: 6 },      // max pupil travel (SVG units)
  waveAngle:  { type: Number, default: -135 },   // arm raise angle in degrees (negative = up/out)
  waveOnClick:{ type: Boolean, default: true },
})
const emit = defineEmits(['wave-start', 'wave-end'])

const uid = Math.random().toString(36).slice(2, 8)
const svgEl = ref(null)

const EYES = { left: { cx: 450.1, cy: 339.7 }, right: { cx: 595.6, cy: 337.7 } }
const ELBOW = { x: 678, y: 772 }
const WRIST = { x: 705, y: 935 }

const look = ref({ lx: 0, ly: 0, rx: 0, ry: 0 })
const armAngle = ref(0)
const handAngle = ref(0)

let target = { lx: 0, ly: 0, rx: 0, ry: 0 }
let waveStart = null
let raf = 0
const WAVE_MS = 2600
const ease = t => t * t * (3 - 2 * t)

function onPointer(e) {
  const el = svgEl.value
  if (!el) return
  const r = el.getBoundingClientRect()
  const s = r.width / 1024
  const aim = (eye) => {
    const dx = e.clientX - (r.left + eye.cx * s)
    const dy = e.clientY - (r.top + eye.cy * s)
    const d = Math.hypot(dx, dy) || 1
    const k = Math.min(1, d / (r.width * 0.25))
    return [dx / d * props.lookRadius * k, dy / d * props.lookRadius * k]
  }
  const [lx, ly] = aim(EYES.left)
  const [rx, ry] = aim(EYES.right)
  target = { lx, ly, rx, ry }
}

function wave() {
  if (waveStart !== null) return
  waveStart = performance.now()
  emit('wave-start')
}

function tick(now) {
  // eyes: ease toward target
  const c = look.value, k = 0.25
  look.value = {
    lx: c.lx + (target.lx - c.lx) * k, ly: c.ly + (target.ly - c.ly) * k,
    rx: c.rx + (target.rx - c.rx) * k, ry: c.ry + (target.ry - c.ry) * k,
  }
  // wave: raise -> swing x3 -> lower
  if (waveStart !== null) {
    const t = Math.min(1, (now - waveStart) / WAVE_MS)
    const base = props.waveAngle
    if (t < 0.15) { armAngle.value = base * ease(t / 0.15); handAngle.value = 0 }
    else if (t < 0.85) {
      const u = (t - 0.15) / 0.7, ph = u * Math.PI * 2 * 3
      armAngle.value = base + 10 * Math.sin(ph)
      handAngle.value = 18 * Math.sin(ph + Math.PI / 2)
    } else { armAngle.value = base * (1 - ease((t - 0.85) / 0.15)); handAngle.value = 0 }
    if (t >= 1) { waveStart = null; armAngle.value = 0; handAngle.value = 0; emit('wave-end') }
  }
  raf = requestAnimationFrame(tick)
}

onMounted(() => {
  window.addEventListener('pointermove', onPointer)
  raf = requestAnimationFrame(tick)
})
onBeforeUnmount(() => {
  window.removeEventListener('pointermove', onPointer)
  cancelAnimationFrame(raf)
})
defineExpose({ wave })
</script>

<template>
  <svg ref="svgEl" class="fm2" viewBox="0 0 1024 1536" xmlns="http://www.w3.org/2000/svg"
       @click="waveOnClick && wave()">
    <defs>
      <clipPath :id="`${uid}-eye-l`"><polygon points="404,345 406,355 412,364 425,371 436,373 438,368 444,364 453,362 459,364 461,363 467,365 470,369 480,365 485,359 485,351 478,338 478,329 477,327 468,318 464,317 458,311 445,308 433,309 429,314 429,321 427,325 420,330 411,334 408,342" /></clipPath>
      <clipPath :id="`${uid}-eye-r`"><polygon points="590,308 585,312 583,317 580,320 576,322 573,322 569,326 567,342 562,351 563,360 569,365 574,367 581,364 584,365 600,361 606,363 608,365 610,371 618,369 631,363 637,356 641,347 640,339 634,332 625,328 623,325 618,323 610,315 608,310 605,307 597,306" /></clipPath>
    </defs>

    <!-- 1. body, hair, clothes (arm removed + background filled in, eyes whited-out) -->
    <image :href="base" x="0" y="0" width="1024" height="1536" />

    <!-- 2. waving arm: rotates around the elbow; hand rotates around the wrist -->
    <g :transform="`rotate(${armAngle} ${ELBOW.x} ${ELBOW.y})`">
      <image :href="armImg" x="640" y="738" width="120" height="228" />
      <g :transform="`rotate(${handAngle} ${WRIST.x} ${WRIST.y})`">
        <image :href="handImg" x="640" y="950" width="120" height="145" />
      </g>
    </g>

    <!-- 3. sleeve cuff sits on top so the arm tucks under it -->
    <image :href="sleeveImg" x="610" y="670" width="130" height="80" />

    <!-- 4. irises, clipped to the eye opening, follow the cursor -->
    <g :clip-path="`url(#${uid}-eye-l)`">
      <g :transform="`translate(${look.lx} ${look.ly})`"><image :href="irisLeftImg" x="410" y="298" width="80" height="77" /></g>
    </g>
    <g :clip-path="`url(#${uid}-eye-r)`">
      <g :transform="`translate(${look.rx} ${look.ry})`"><image :href="irisRightImg" x="557" y="296" width="78" height="80" /></g>
    </g>

    <!-- 5. upper lashes stay on top of the irises -->
    <image :href="lashesImg" x="396" y="300" width="256" height="90" />
  </svg>
</template>

<style scoped>
.fm2 { height: 100%; width: auto; cursor: pointer; user-select: none; }
</style>
